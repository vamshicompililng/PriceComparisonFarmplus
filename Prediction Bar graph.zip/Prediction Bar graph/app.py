from flask import Flask, render_template, request
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

app = Flask(__name__)


data = pd.read_csv('test_dataset.csv')


data.columns = data.columns.str.strip()


X = data.drop(['Market Price (per quintal in rupees)'], axis=1)
y = data['Market Price (per quintal in rupees)']


label_encoders = {}
for column in X.select_dtypes(include=['object']).columns:
    le = LabelEncoder()
    X[column] = le.fit_transform(X[column].astype(str))  
    label_encoders[column] = le


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

def make_prediction(crop_name, growth_duration, cost_cultivation, crop_type,
                    fertilizers, region, soil_type, yield_value, weather, year):

    input_data = pd.DataFrame({
        'Crop Name': [crop_name],
        'Growth Duration (days)': [growth_duration],
        'Cost of Cultivation (in rupees)': [cost_cultivation],
        'Crop Type': [crop_type],
        'Fertilizers Used': [fertilizers],
        'Region': [region],
        'Soil Type': [soil_type],
        'Yield (kg/ha)': [yield_value],
        'Weather Conditions': [weather],
        'Year': [year]
    })


    input_data.columns = input_data.columns.str.strip()


    for column in input_data.select_dtypes(include=['object']).columns:
        if column in label_encoders:
            try:
                input_data[column] = label_encoders[column].transform(input_data[column].astype(str))
            except ValueError:

                input_data[column] = np.nan


    prediction = model.predict(input_data)
    return prediction[0]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:

        crops_data = []
        for i in range(1, 6): 
            crop_name = request.form[f'crop{i}Name']
            growth_duration = int(request.form[f'crop{i}GrowthDuration'])
            cost_cultivation = float(request.form[f'crop{i}Cost'])
            crop_type = request.form[f'crop{i}Type']
            fertilizers = request.form[f'crop{i}Fertilizers']
            region = request.form[f'crop{i}Region']
            soil_type = request.form[f'crop{i}SoilType']
            yield_value = float(request.form[f'crop{i}Yield'])
            weather = request.form[f'crop{i}Weather']
            year = int(request.form[f'crop{i}Year'])

            predicted_value = make_prediction(crop_name, growth_duration, cost_cultivation,
                                               crop_type, fertilizers, region, soil_type,
                                               yield_value, weather, year)
            crops_data.append({
                'name': crop_name,
                'predicted_price': predicted_value
            })

        return render_template('index.html', crops=crops_data)
    
    except Exception as e:
        return render_template('index.html', error_text=str(e))

if __name__ == '__main__':
    app.run(debug=True)